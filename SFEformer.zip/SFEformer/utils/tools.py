import numpy as np
import torch
import matplotlib.pyplot as plt
import time
import seaborn as sns
plt.switch_backend('agg')
import matplotlib.font_manager as fm

def adjust_learning_rate(optimizer, scheduler, epoch, args, printout=True):
    # lr = args.learning_rate * (0.2 ** (epoch // 2))
    if args.lradj == 'type1':
        lr_adjust = {epoch: args.learning_rate * (0.5 ** ((epoch - 1) // 1))}
    elif args.lradj == 'type2':
        lr_adjust = {
            2: 5e-5, 4: 1e-5, 6: 5e-6, 8: 1e-6,
            10: 5e-7, 15: 1e-7, 20: 5e-8
        }
    elif args.lradj == 'type3':
        lr_adjust = {epoch: args.learning_rate if epoch < 3 else args.learning_rate * (0.9 ** ((epoch - 3) // 1))}
    elif args.lradj == 'constant':
        lr_adjust = {epoch: args.learning_rate}
    elif args.lradj == '3':
        lr_adjust = {epoch: args.learning_rate if epoch < 10 else args.learning_rate*0.1}
    elif args.lradj == '4':
        lr_adjust = {epoch: args.learning_rate if epoch < 15 else args.learning_rate*0.1}
    elif args.lradj == '5':
        lr_adjust = {epoch: args.learning_rate if epoch < 25 else args.learning_rate*0.1}
    elif args.lradj == '6':
        lr_adjust = {epoch: args.learning_rate if epoch < 5 else args.learning_rate*0.1}
    elif args.lradj == 'TST':
        lr_adjust = {epoch: scheduler.get_last_lr()[0]}

    if epoch in lr_adjust.keys():
        lr = lr_adjust[epoch]
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr
        if printout: print('Updating learning rate to {}'.format(lr))

class EarlyStopping_o:
    def __init__(self, patience=7, verbose=False, delta=0):
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta

    def __call__(self, val_loss, model, path):
        score = -val_loss
        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model, path)
        #elif score < self.best_score + self.delta:
        #    self.counter += 1
        #    print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
        #    if self.counter >= self.patience:
        #        self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model, path)
            self.counter = 0

    def save_checkpoint(self, val_loss, model, path):
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).  Saving model ...')
        torch.save(model.state_dict(), path + '/' + 'checkpoint.pth')
        self.val_loss_min = val_loss

class EarlyStopping:
    def __init__(self, patience=7, verbose=False, delta=0):
        self.patience = patience
        self.verbose = verbose
        self.counter = 0
        self.best_score = None
        self.early_stop = False
        self.val_loss_min = np.Inf
        self.delta = delta

    def __call__(self, val_loss, model, path):
        score = -val_loss
        if self.best_score is None:
            self.best_score = score
            self.save_checkpoint(val_loss, model, path)
        elif score < self.best_score + self.delta:
            self.counter += 1
            print(f'EarlyStopping counter: {self.counter} out of {self.patience}')
            if self.counter >= self.patience:
                self.early_stop = True
        else:
            self.best_score = score
            self.save_checkpoint(val_loss, model, path)
            self.counter = 0

    def save_checkpoint(self, val_loss, model, path):
        if self.verbose:
            print(f'Validation loss decreased ({self.val_loss_min:.6f} --> {val_loss:.6f}).  Saving model ...')
        torch.save(model.state_dict(), path + '/' + 'checkpoint.pth')
        self.val_loss_min = val_loss


class dotdict(dict):
    """dot.notation access to dictionary attributes"""
    __getattr__ = dict.get
    __setattr__ = dict.__setitem__
    __delattr__ = dict.__delitem__


class StandardScaler():
    def __init__(self, mean, std):
        self.mean = mean
        self.std = std

    def transform(self, data):
        return (data - self.mean) / self.std

    def inverse_transform(self, data):
        return (data * self.std) + self.mean




# def visual(true, preds=None,name='./pic/results.pdf',):
#     """
#     Results visualization
#     """
#     plt.style.use('seaborn-muted')
#     plt.figure()
#     plt.plot(true, label='GroundTruth', linewidth=2.1)
#     if preds is not None:
#         plt.plot(preds, label='Prediction', linewidth=2.1)
#     plt.legend()#loc="upper right"
#     plt.savefig(name,bbox_inches='tight')
#
#     if preds is not None:
#         # Calculate prediction error
#         errors = true - preds
#
#         # Plot 2: Prediction Error curve 预测误差
#         plt.figure()
#         plt.plot(errors, label='Prediction Error', color='r', linewidth=2.1)
#         plt.legend()
#         plt.title('Prediction Error Over Time')
#         plt.xlabel('Time')
#         plt.ylabel('Error')
#         plt.savefig(name.replace('.pdf', '_error_curve.pdf'), bbox_inches='tight')
#
#         # Plot 3: True vs Predicted values scatter plot 散点图
#         plt.figure()
#         plt.scatter(true, preds, alpha=0.6)
#         plt.plot([min(true), max(true)], [min(true), max(true)], color='r', linestyle='--')  # 45 degree line
#         plt.title('Scatter Plot of True Values vs. Predicted Values')
#         plt.xlabel('True Values')
#         plt.ylabel('Predicted Values')
#         plt.savefig(name.replace('.pdf', '_scatter.pdf'), bbox_inches='tight')
#
#         #Plot 4: Prediction Error distribution plot 误差的概率分布
#         plt.figure()
#         sns.histplot(errors, kde=True, bins=30)
#         plt.title('Prediction Error Distribution')
#         plt.xlabel('Error')
#         plt.ylabel('Frequency')
#         plt.savefig(name.replace('.pdf', '_error_dist.pdf'), bbox_inches='tight')
#
#     plt.show()

# def visual(true, preds=None, name='./pic/test.pdf',
#            color_groundtruth='#0079C3', color_prediction='#f08300',
#            color_error='#4ED4C8', font='Times New Roman', font_size=12):
#     """
#     Results visualization with custom colors and fonts.
#     """
#     plt.style.use('seaborn-muted')
#     # 设置字体
#     plt.rcParams['font.family'] = font
#     plt.rcParams['font.size'] = font_size
#
#     # Plot 1: GroundTruth vs Prediction curve
#     plt.figure()
#     plt.plot(true, label='GroundTruth', color=color_groundtruth, linewidth=2)
#     if preds is not None:
#         plt.plot(preds, label='Prediction', color=color_prediction, linestyle='--',linewidth=2)
#     plt.legend()
#     plt.title('GroundTruth vs Prediction')
#     plt.savefig(name, bbox_inches='tight')
#
#     if preds is not None:
#         # Calculate prediction error
#         errors = true - preds
#
#         # Plot 2: Prediction Error curve 预测误差
#         # plt.figure()
#         # plt.plot(errors, label='Prediction Error', color=color_error,  linewidth=2)
#         # plt.legend()
#         # plt.title('Prediction Error Over Time')
#         # plt.xlabel('Time')
#         # plt.ylabel('Error')
#         # plt.savefig(name.replace('.pdf', '_error_curve.pdf'), bbox_inches='tight')
#
#         # Plot 3: True vs Predicted values scatter plot 散点图
#         plt.figure()
#         plt.scatter(true, preds, color=color_prediction, alpha=0.6)
#         plt.plot([min(true), max(true)], [min(true), max(true)], color=color_error, linestyle='--')  # 45 degree line
#         plt.title(' True Values vs. Predicted Values')
#         plt.xlabel('True Values')
#         plt.ylabel('Predicted Values')
#         plt.savefig(name.replace('.pdf', '_scatter.pdf'), bbox_inches='tight')
#
#         # Plot 4: Prediction Error distribution plot 误差的概率分布
#         plt.figure()
#         sns.histplot(errors, kde=True, color=color_error, bins=30,edgecolor=None)
#         plt.title('Prediction Error ')
#         plt.xlabel('Error')
#         plt.ylabel('Frequency')
#         plt.savefig(name.replace('.pdf', '_error_dist.pdf'), bbox_inches='tight')
#
#     plt.show()
# import matplotlib.pyplot as plt
# import seaborn as sns
# import numpy as np
# from sklearn.metrics import r2_score
#
# def visual(true, preds=None, name='./pic/test.pdf',
#            color_groundtruth='#0079C3', color_prediction='#f08300',
#            color_error='#0079C3', font='Times New Roman', font_size=12):
#     """
#     Results visualization with custom colors and fonts.
#     """
#     plt.style.use('seaborn-muted')
#     # 设置字体
#     plt.rcParams['font.family'] = font
#     plt.rcParams['font.size'] = font_size
#
#     # Plot 1: GroundTruth vs Prediction curve
#     plt.figure()
#     plt.plot(true, label='GroundTruth', color=color_groundtruth, linewidth=2)
#     if preds is not None:
#         plt.plot(preds, label='Prediction', color=color_prediction, linestyle='--', linewidth=2)
#     plt.legend()
#     plt.title('GroundTruth vs Prediction')
#     plt.savefig(name, bbox_inches='tight')
#
#     if preds is not None:
#         # Calculate prediction error
#         errors = true - preds
#
#         # Plot 2: True vs Predicted values scatter plot with R²
#         plt.figure()
#         plt.scatter(true, preds, color=color_prediction, alpha=0.3)
#         plt.plot([min(true), max(true)], [min(true), max(true)], color=color_prediction, linestyle='--')  # 45 degree line
#         r2 = r2_score(true, preds)
#         plt.title(f'True Values vs. Predicted Values\n$R^2$ = {r2:.2f}')
#         plt.xlabel('True Values')
#         plt.ylabel('Predicted Values')
#         plt.savefig(name.replace('.pdf', '_scatter_r2.pdf'), bbox_inches='tight')
#
#         # Plot 3: Prediction Error distribution plot with µ and σ
#         plt.figure()
#         sns.histplot(errors, kde=True, color=color_error, bins=30, edgecolor=None)
#         mu = np.mean(errors)
#         sigma = np.std(errors)
#         plt.title(f'Prediction Error Distribution\n$\\mu$ = {mu:.2f}, $\\sigma$ = {sigma:.2f}')
#         plt.xlabel('Error')
#         plt.ylabel('Frequency')
#         plt.savefig(name.replace('.pdf', '_error_dist_mu_sigma.pdf'), bbox_inches='tight')
#
#     plt.show()
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from sklearn.metrics import r2_score


def visual(true, preds=None, name='./pic/test.jpg',
           color_groundtruth='#0079C3', color_prediction='#f08300',
           color_error='#0079C3', font='DejaVu Sans', font_size=10):
    """
    Results visualization with custom colors and fonts.
    """
    plt.style.use('seaborn-muted')
    # 设置字体
    plt.rcParams['font.family'] = font
    plt.rcParams['font.size'] = font_size

    # Plot 1: GroundTruth vs Prediction curve
    plt.figure()
    plt.plot(true, label='GroundTruth', color=color_groundtruth, linewidth=3)
    if preds is not None:
        plt.plot(preds, label='Prediction', color=color_prediction, linestyle='--', linewidth=3)
    plt.legend()
    plt.title('GroundTruth vs Prediction')
    plt.savefig(name, dpi=600, bbox_inches='tight', format='jpg')  # Save as 600 DPI JPEG

    if preds is not None:
        # Calculate prediction error
        errors = true - preds

        # Plot 2: True vs Predicted values scatter plot with R²
        plt.figure()
        plt.scatter(true, preds, color=color_prediction, alpha=0.8)
        plt.plot([min(true), max(true)], [min(true), max(true)], color=color_prediction,
                 linestyle='--')  # 45 degree line
        r2 = r2_score(true, preds)
        plt.title(f'True Values vs. Predicted Values\n$R^2$ = {r2:.2f}')
        plt.xlabel('True Values')
        plt.ylabel('Predicted Values')
        scatter_r2_name = name.replace('.jpg', '_scatter_r2.jpg')  # Ensure the correct file name
        plt.savefig(scatter_r2_name, dpi=600, bbox_inches='tight', format='jpg')  # Save as 600 DPI JPEG

        # Plot 3: Prediction Error distribution plot with µ and σ
        plt.figure()
        ax = sns.histplot(errors, kde=True, color=color_error, bins=30, edgecolor=None)

        # Add vertical lines for mean and standard deviation with dashed style
        mu = np.mean(errors)
        sigma = np.std(errors)
        plt.axvline(mu, color='red', linestyle='--', linewidth=2, label=f'$\\mu$ = {mu:.2f}')
        plt.axvline(mu + sigma, color='green', linestyle='--', linewidth=2, label=f'$\\sigma$ = {sigma:.2f}')
        plt.axvline(mu - sigma, color='green', linestyle='--', linewidth=2)

        plt.title(f'Prediction Error Distribution\n$\\mu$ = {mu:.2f}, $\\sigma$ = {sigma:.2f}')
        plt.xlabel('Error')
        plt.ylabel('Frequency')
        plt.legend()
        error_dist_name = name.replace('.jpg', '_error_dist_mu_sigma.jpg')  # Ensure the correct file name
        plt.savefig(error_dist_name, dpi=600, bbox_inches='tight', format='jpg')  # Save as 600 DPI JPEG

    plt.show()


def test_params_flop(model,x_shape):
    """
    If you want to thest former's flop, you need to give default value to inputs in model.forward(), the following code can only pass one argument to forward()
    """
    model_params = 0
    for parameter in model.parameters():
        model_params += parameter.numel()
        print('INFO: Trainable parameter count: {:.2f}M'.format(model_params / 1000000.0))
    from ptflops import get_model_complexity_info
    with torch.cuda.device(0):
        macs, params = get_model_complexity_info(model.cuda(), x_shape, as_strings=True, print_per_layer_stat=True)
        # print('Flops:' + flops)
        # print('Params:' + params)
        print('{:<30}  {:<8}'.format('Computational complexity: ', macs))
        print('{:<30}  {:<8}'.format('Number of parameters: ', params))


