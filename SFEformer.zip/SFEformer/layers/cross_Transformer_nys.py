import torch
import torch.nn.functional as F
import torch.nn as nn
from torch.nn.utils import weight_norm

import math
import torch.optim as optim
from math import ceil
from torch.autograd.function import Function
import os
import pickle
import numpy as np
import pandas as pd
import math
from itertools import chain
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report
import itertools
import random
import tqdm
from IPython.display import display, HTML
import matplotlib.pyplot as plt
from scipy import signal
from scipy.fft import fftshift

from einops import rearrange, repeat, reduce
from einops.layers.torch import Rearrange
from torch import nn, einsum

import logging
from functools import partial
from collections import OrderedDict
from sklearn.metrics import classification_report
import time


#
import torch
import torch.nn as nn
from einops import rearrange


class Trans_C(nn.Module):
    def __init__(self, *, dim, depth, heads, mlp_dim, dim_head, dropout, patch_dim, horizon, d_model):
        super().__init__()

        self.dim = dim
        self.patch_dim = patch_dim

        # Patch embedding
        self.to_patch_embedding = nn.Sequential(
            nn.Linear(patch_dim, dim),
            nn.Dropout(dropout)
        )

        # Multi-head Attention
        self.attention = nn.MultiheadAttention(embed_dim=dim, num_heads=heads, dropout=dropout)

        # Temporal Key-Aware Network (TKAN) components
        self.temporal_key_linear = nn.Linear(dim, dim)
        self.temporal_value_linear = nn.Linear(dim, dim)

        # LSTM for long-term dependencies
        self.lstm = nn.LSTM(input_size=dim, hidden_size=dim, num_layers=1, batch_first=True)

        # FeedForward layer
        self.feedforward = nn.Sequential(
            nn.Linear(dim, mlp_dim),
            nn.GELU(),
            nn.Dropout(dropout),
            nn.Linear(mlp_dim, dim),
            nn.Dropout(dropout)
        )

        # Output head
        self.mlp_head = nn.Linear(dim, d_model)

    def adaptive_conv(self, x):
        """
        自适应卷积：根据输入数据的统计特性动态调整卷积核和步长
        x: 输入特征，shape为 (batch_size, seq_len, dim)
        """
        batch_size, seq_len, _ = x.shape


        local_variance = torch.var(x, dim=1)


        kernel_size = torch.clamp((local_variance.mean() * 10).int(), min=2,
                                  max=5).item()  # 使用 .item() 将 Tensor 转换为 Python 数字
        stride = max(1, min(seq_len // 10, 2))  # 动态计算步长大小


        kernel_size = min(kernel_size, seq_len)


        conv = nn.Conv1d(self.dim, self.dim, kernel_size=kernel_size, stride=stride)


        conv = conv.to(x.device)


        x = x.permute(0, 2, 1)
        x = conv(x)
        x = x.permute(0, 2, 1)

        return x

    def forward(self, x):
        # Patch embedding
        x = self.to_patch_embedding(x)


        x = self.adaptive_conv(x)

        keys = self.temporal_key_linear(x)  # (batch_size, seq_len, dim)
        values = self.temporal_value_linear(x)  # (batch_size, seq_len, dim)


        lstm_output, _ = self.lstm(keys)
        x = lstm_output + keys


        x = rearrange(x, 'b n d -> n b d')  # (seq_len, batch_size, dim)
        attn_output, _ = self.attention(x, x, x)  # Using x for queries, keys, and values
        x = attn_output + x  # Residual connection


        x = rearrange(x, 'n b d -> b n d')  # (batch_size, seq_len, dim)
        x = self.feedforward(x) + x

        # Final output head
        x = self.mlp_head(x).squeeze()  # Final MLP head and remove sequence length dimension
        return x
