import torch
import torch.nn as nn


#1GAN
import torch
import torch.nn as nn





class Generator(nn.Module):
    def __init__(self, num_features):
        super(Generator, self).__init__()
        self.fc1 = nn.Linear(num_features, num_features)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(num_features, num_features)

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return x


class Discriminator(nn.Module):
    def __init__(self, num_features):
        super(Discriminator, self).__init__()
        self.fc1 = nn.Linear(num_features, num_features)
        self.relu = nn.ReLU()
        self.fc2 = nn.Linear(num_features, 1)
        self.sigmoid = nn.Sigmoid()

    def forward(self, x):
        x = self.fc1(x)
        x = self.relu(x)
        x = self.fc2(x)
        return self.sigmoid(x)


class RevIN(nn.Module):
    def __init__(self, num_features: int, eps=1e-5, affine=True, subtract_last=False):
        super(RevIN, self).__init__()
        self.num_features = num_features
        self.eps = eps
        self.affine = affine
        self.subtract_last = subtract_last
        self.generator = Generator(num_features)  # Initialize the Generator
        self.discriminator = Discriminator(num_features)  # Initialize the Discriminator

        if self.affine:
            self._init_params()

    def forward(self, x, mode: str, meta_data=None):
        if mode == 'norm':
            if meta_data is not None:
                # Use Generator to get dynamic statistics
                normalized_data = self.generator(meta_data)
                mean, std = normalized_data.chunk(2, dim=-1)
            else:
                # Use static statistics
                self._get_statistics(x)
                mean, std = self.mean, self.stdev

            x = (x - mean) / (std + self.eps)
            if self.affine:
                x = x * self.affine_weight
                x = x + self.affine_bias

        elif mode == 'denorm':
            if meta_data is not None:
                # Use Generator to get dynamic statistics
                normalized_data = self.generator(meta_data)
                mean, std = normalized_data.chunk(2, dim=-1)
            else:
                # For 'denorm' mode, if meta_data is None, use previously computed mean and std
                if not hasattr(self, 'mean') or not hasattr(self, 'stdev'):
                    raise ValueError("Meta data or previously computed statistics are required for 'denorm' mode")
                mean, std = self.mean, self.stdev

            if self.affine:
                x = (x - self.affine_bias) / (self.affine_weight + self.eps)
            x = x * (std + self.eps) + mean

        else:
            raise NotImplementedError("Mode should be 'norm' or 'denorm'")
        return x






    def _init_params(self):
        self.affine_weight = nn.Parameter(torch.ones(self.num_features))
        self.affine_bias = nn.Parameter(torch.zeros(self.num_features))

    def _get_statistics(self, x):
        dim2reduce = tuple(range(1, x.ndim - 1))
        if self.subtract_last:
            self.last = x[:, -1, :].unsqueeze(1)
            self.mean = self.last
            self.stdev = torch.ones_like(self.last)
        else:
            self.mean = torch.mean(x, dim=dim2reduce, keepdim=True).detach()
            self.stdev = torch.sqrt(torch.var(x, dim=dim2reduce, keepdim=True, unbiased=False) + self.eps).detach()


